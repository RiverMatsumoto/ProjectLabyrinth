using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IBoolean
{
	bool _Value { get; }
}